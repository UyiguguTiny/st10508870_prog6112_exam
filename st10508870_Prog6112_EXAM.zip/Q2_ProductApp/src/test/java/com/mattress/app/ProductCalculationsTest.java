package com.mattress.app;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Unit tests for the ProductCalculations class (Q.2.6).
 * Uses the sample price of R3500 from the question paper.
 */
public class ProductCalculationsTest {

    private static final double DELTA = 0.001;

    /** Unit Test 1: GetVat returns 15% of the price. */
    @Test
    public void GetVat_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(525.0, calc.GetVat(), DELTA);
    }

    /** Unit Test 2: GetTotal returns price + VAT + commission. */
    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(4200.0, calc.GetTotal(), DELTA);
    }

    /** Extra test: GetCommission returns 5% of the price. */
    @Test
    public void GetCommission_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calc = new ProductCalculations(3500);
        assertEquals(175.0, calc.GetCommission(), DELTA);
    }
}

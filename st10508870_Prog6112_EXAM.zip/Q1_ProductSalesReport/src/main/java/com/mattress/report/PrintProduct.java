package com.mattress.report;

/**
 * Responsible only for printing the report (Q.1.3).
 * All calculations are delegated to the Product class.
 */
public class PrintProduct {

    private static final String DIVIDER = "*".repeat(40);
    private final Product product;

    public PrintProduct(Product product) {
        this.product = product;
    }

    public void printReportHeader() {
        System.out.println();
        System.out.println("PRODUCT SALES REPORT - 2026");
        System.out.println();
        System.out.println(DIVIDER);
    }

    public void printTotalProductSales() {
        System.out.println("TOTAL PRODUCT SALES: " + product.GetTotalProductsSold());
    }

    public void printAverageProductSales() {
        // Rounded to a whole number to match the sample output (17)
        System.out.printf("AVERAGE PRODUCT SALES: %.0f%n", product.GetAverageProductSold());
    }

    public void printMostPopularProduct() {
        int index = product.getMostPopularIndex();
        // Bracket shows the product's best month, as in the sample: Cozy Nights Monarch(25)
        System.out.println("MOST POPULAR PRODUCT: " + product.GetMostPopularProduct()
                + "(" + product.getHighestMonthlySale(index) + ")");
    }

    /** Prints the full report in the required order. */
    public void printReport() {
        printReportHeader();
        printTotalProductSales();
        printAverageProductSales();
        printMostPopularProduct();
    }
}

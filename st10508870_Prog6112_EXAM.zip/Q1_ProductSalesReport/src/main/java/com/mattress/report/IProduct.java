package com.mattress.report;

/**
 * Contract for the product sales calculations (Q.1.2).
 * Method names are kept exactly as given in the question paper.
 */
public interface IProduct {

    int GetTotalProductsSold();

    double GetAverageProductSold();

    String GetMostPopularProduct();
}

package com.mattress.report;

import java.util.Scanner;

/**
 * Entry point for Question 1.
 * Captures three months of sales for three products, then prints the report.
 */
public class ProductSalesReport {

    private static final int MONTHS = 3;

    public static void main(String[] args) {
        // Single-dimensional array: product names
        String[] productNames = {"Cozy Nights Monarch", "Restonic Barbados", "Sealy Phuket"};

        // Two-dimensional array: rows = products, columns = months
        int[][] sales = new int[productNames.length][MONTHS];

        Scanner input = new Scanner(System.in);

        for (int p = 0; p < productNames.length; p++) {
            for (int m = 0; m < MONTHS; m++) {
                String prompt = "Enter number of sales for month " + (m + 1)
                        + " for " + productNames[p] + " mattress: ";
                sales[p][m] = readNonNegativeInt(input, prompt);
            }
            System.out.println(); // blank line between products, as in the sample
        }

        Product product = new Product(productNames, sales);
        PrintProduct printer = new PrintProduct(product);
        printer.printReport();

        input.close();
    }

    /** Keeps asking until the user enters a whole number of zero or more. */
    private static int readNonNegativeInt(Scanner input, String prompt) {
        while (true) {
            System.out.print(prompt);
            String line = input.nextLine().trim();
            try {
                int value = Integer.parseInt(line);
                if (value >= 0) {
                    return value;
                }
                System.out.println("Sales cannot be negative. Please try again.");
            } catch (NumberFormatException e) {
                System.out.println("Please enter a whole number.");
            }
        }
    }
}
